# Transformer-Neural-Network
Code Transformer neural network components piece by piece. 

[Full Playlist](https://www.youtube.com/playlist?list=PLTl9hO2Oobd97qfWC40gOSU8C0iu0m2l4)
